import * as react from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import RedDead2 from './Jogos/RedDead2';
import Minecraft from './Jogos/Minecraft';
import GrandTheftAuto from './Jogos/GrandTheftAuto';
import Fortnite from './Jogos/Fortnite';
import Jogos from './pages/Jogos';

const Stack = createStackNavigator();

export default function RotasButtomJogos() {
  return (
    <Stack.Navigator>
    <Stack.Screen name="Jogos" component={Jogos} options = {{headerShown:false}} />
    <Stack.Screen name="RedDead2" component={RedDead2} options = {{title:"Red Dead Redemption2"}} />
    <Stack.Screen name="Minecraft" component={Minecraft} options = {{title:"Minecraft"}} />
    <Stack.Screen name="GrandTheftAuto" component={GrandTheftAuto} options = {{title:"Grand Theft Auto 5"}} />
    <Stack.Screen name="Fortnite" component={Fortnite} options = {{title:"Fortnite"}} />
    </Stack.Navigator>
  );
}

