import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView} from 'react-native';

export default function Michael() {
  return (
    <ScrollView>
    <View style={estilo.container}>
    <Text style={estilo.titulo}> Michael</Text>
    <View>
    <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
    <View>
    <Image
     resizeMode={'stretch'}
     style={estilo.img}
     source={require('../../assets/Michael1.webp')}
     />
     </View>
     

    <View>
    <Image
     resizeMode={'stretch'}
     style={estilo.img}
     source={require('../../assets/Michael2.webp')}
     />
     </View>

         <View>
    <Image
     resizeMode={'stretch'}
     style={estilo.img}
     source={require('../../assets/Michael3.jpg')}
     />
     </View>
     </ScrollView>
     </View>
     <View style={estilo.resumo}>
     <Text style={estilo.textoResumo}>
Michael De Santa , anteriormente conhecido como Michael Townley , é um personagem que aparece como um dos três protagonistas de Grand Theft Auto V , ao lado de Franklin Clinton e Trevor Philips , e como personagem principal em Grand Theft Auto Online como parte da atualização A Safehouse in the Hills . Ele é interpretado por Ned Luke .

Michael é um criminoso de carreira aposentado e assaltante de bancos que vive em Los Santos , San Andreas , com sua família sob novas identidades, após ter feito um acordo secreto com o agente corrupto do FIB, Dave Norton , que o ajudou a forjar sua morte. Insatisfeito com seu estilo de vida aparentemente idílico e tranquilo, e desejando reviver seus "dias de glória", Michael eventualmente retorna à vida do crime, o que traz consequências imprevistas, pois ele é forçado a confrontar demônios do passado que voltam para assombrá-lo.

Ao final da história de Grand Theft Auto V , Michael encontra um novo conforto em sua vida como homem de família e abandona mais uma vez sua carreira criminosa para se tornar produtor de cinema. Em 2025 , durante os eventos de Grand Theft Auto Online , ele ainda mantém essa posição, tendo fundado sua própria produtora cinematográfica, De Santa , que lhe trouxe muita fama e sucesso.
</Text>
      </View>
      </View>
      </ScrollView>
  );
}
const estilo = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#800020',
  },
  img: {
    width: 360,
    height: 400,
    marginHorizontal: 25,
    borderRadius: 10,
  },
  titulo: {
    fontSize: 30,
    textAlign: 'center',
    color: '#FFC0CB',
    fontWeight: 700,
    marginTop: 50,
    marginBottom: 30,
  },
  resumo: {
    marginTop: 20,
    marginHorizontal: 15,
    backgroundColor: '#ffffff70',
    color: '#FFFFE0',
    borderRadius: 7,
    padding: 8,
  },
  textoResumo: {
    fontSize: 19,
  },
});