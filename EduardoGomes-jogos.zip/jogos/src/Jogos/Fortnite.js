import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';

export default function Fortnite() {
  const jogos = 
`Fortnite é um jogo eletrônico multijogador online e uma plataforma de jogos desenvolvida pela Epic Games e lançada em 2017. Está disponível em sete modos distintos, que compartilham a jogabilidade e o mesmo motor gráfico. Os modos de jogo incluem Fortnite: Save the World, um jogo cooperativo pay to play de sobrevivência e tower defense no qual até quatro jogadores enfrentam criaturas semelhantes a zumbis e defendem objetivos usando armadilhas e estruturas; Fortnite Battle Royale, um jogo free to play do gênero battle royale, onde até 100 jogadores lutam em espaços cada vez menores para serem a última pessoa ou time vencedor; Fortnite Creative [en] que oferece liberdade total para criação de mapas, ilhas e arenas; Lego Fortnite, um conjunto de jogos de mundo aberto dividido entre o modo de sobrevivência Lego Fortnite Odyssey e o modo social Lego Fortnite Brick Life; Rocket Racing, um jogo de corrida; Fortnite Festival, um jogo de ritmo e Fortnite Ballistic [en], um jogo de tiro em primeira pessoa atualmente em acesso antecipado. Em 24 de março de 2026, a Epic disse que irá descontinuar 1 modo e remover 2 modos de jogo. entre eles estão Ballistic, Festival Battle Stage e Rocket Racing. a decisão foi tomada devido a baixa quantidade de jogadores ativos em ambos os modos. Ballistic e Festival Battle Stage serão removidos em 16 de abril, enquanto Rocket Racing será descontinuado em outubro de 2026.[3][4]

Os modos Fortnite: Save the World e Fortnite Battle Royale foram lançados em 2017 como títulos de acesso antecipado; Save the World está disponível apenas para Microsoft Windows, PlayStation 4 e Xbox One, enquanto Battle Royale foi lançado para essas mesmas plataformas, incluindo o Nintendo Switch e dispositivos Android. Em 2020, foi adicionado para a nova geração de consoles PlayStation 5 e Xbox Series X/S.

Embora ambos os modos de jogo tenham sido bem-sucedidos para a Epic Games, o Fortnite Battle Royale se tornou um sucesso, atraindo mais de 125 milhões de jogadores em menos de um ano e ganhando centenas de milhões de dólares por mês, e desde então tem sido um fenômeno cultural. Todos os modos, exceto Save the World, são free-to-play

`;

  return (
    <ScrollView>
      <View style={estilo.container}>
        <Text style={estilo.titulo}>Fortnite</Text>
        <Text style={estilo.subtitulo}>
        Epic Games
        </Text>

        <View style={estilo.resumo}>
          <Text style={estilo.textoResumo}>
            {jogos}
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const estilo = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#800020',
    paddingBottom: 30,
  },
  titulo: {
    fontSize: 30,
    textAlign: 'center',
    color: '#D3AF37',
    fontWeight: '700',
    marginTop: 50,
    marginBottom: 10,
  },
  subtitulo: {
    fontSize: 20,
    textAlign: 'center',
    color: '#E6E6FA',
    marginBottom: 20,
  },
  resumo: {
    marginHorizontal: 25,
    backgroundColor: '#ffffff70',
    borderRadius: 7,
    padding: 12,
  },
  textoResumo: {
    fontSize: 16,
    lineHeight: 27,
    color: '#FFFFE0',
  },
});