import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';

export default function RedDead2() {
  const jogos = 
`Red Dead Redemption 2 (estilizado Red Dead Redemption II) é um jogo eletrônico de ação-aventura desenvolvido e publicado pela Rockstar Games. É o terceiro título da série Red Dead e uma prequela de Red Dead Redemption, tendo sido lançado em outubro de 2018 para PlayStation 4 e Xbox One e em novembro de 2019 para Microsoft Windows e Google Stadia. A história se passa em 1899 em uma representação ficcional do oeste, meio-oeste e sul dos Estados Unidos e acompanha o fora da lei Arthur Morgan, que precisa lidar com o declínio do Velho Oeste e sobreviver à perseguição de forças governamentais, gangues rivais e outros adversários.

A jogabilidade é apresentada tanto em uma perspectiva em primeira quanto em terceira pessoa, com o jogador sendo livre para explorar e interagir com o mundo aberto. Elementos de jogabilidade incluem tiroteios, assaltos, caça, cavalgadas, interação com personagens não jogáveis e gerenciamento da honra do protagonista por meio de escolhas morais e atos. Um sistema de recompensa similar àquele presente na série Grand Theft Auto governa as respostas da polícia e caçadores de recompensa aos crimes cometidos pelo jogador. Um modo multijogador chamado de Red Dead Online estreou em novembro de 2018.

O desenvolvimento do título começou logo depois do lançamento de Red Dead Redemption em 2010 e foi compartilhado entre todas desenvolvedoras da Rockstar Games ao redor do mundo. A equipe se inspirou em locais reais, focando-se na criação de uma reflexão fiel do período temporal por meio dos personagens e do mundo de jogo. Red Dead Redemption 2 foi o primeiro jogo da Rockstar Games desenvolvido especificamente para os consoles da oitava geração. A trilha sonora original inclui músicas orquestrais compostas por Woody Jackson e várias faixas vocais produzidas por Daniel Lanois.

Red Dead Redemption 2 foi amplamente antecipado pré-estreia, tendo batido vários recordes e tornando-se o segundo maior lançamento da indústria do entretenimento. Ele arrecadou mais de 725 milhões de dólares em seu fim de semana de estreia e superou as vendas totais do primeiro Red Dead Redemption em apenas duas semanas, já tendo vendido mundialmente mais de 74 milhões de cópias até março de 2025.[1] Ele foi aclamado pela crítica especializada, com elogios direcionados para sua história, personagens, mundo aberto e nível de detalhes. Considerado por múltiplas publicações como um dos melhores jogos eletrônicos de todos os tempos, Red Dead Redemption 2 também venceu diversos prêmios de final de ano, incluindo alguns de Jogo do Ano.
`;

  return (
    <ScrollView>
      <View style={estilo.container}>
        <Text style={estilo.titulo}>Red Dead Redemption 2</Text>
        <Text style={estilo.subtitulo}>
        Rockstar Games
        </Text>

        <View style={estilo.resumo}>
          <Text style={estilo.textoResumo}>
            {jogos}
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const estilo = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#800020',
    paddingBottom: 30,
  },
  titulo: {
    fontSize: 30,
    textAlign: 'center',
    color: '#D3AF37',
    fontWeight: '700',
    marginTop: 50,
    marginBottom: 10,
  },
  subtitulo: {
    fontSize: 20,
    textAlign: 'center',
    color: '#E6E6FA',
    marginBottom: 20,
  },
  resumo: {
    marginHorizontal: 25,
    backgroundColor: '#ffffff70',
    borderRadius: 7,
    padding: 12,
  },
  textoResumo: {
    fontSize: 16,
    lineHeight: 27,
    color: '#FFFFE0',
  },
});