import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView} from 'react-native';

export default function Jonesy() {
  return (
    <ScrollView>
    <View style={estilo.container}>
    <Text style={estilo.titulo}> Jonesy</Text>
    <View>
    <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
    <View>
    <Image
     resizeMode={'stretch'}
     style={estilo.img}
     source={require('../../assets/Jonesy1.jpg')}
     />
     </View>
     

    <View>
    <Image
     resizeMode={'stretch'}
     style={estilo.img}
     source={require('../../assets/Jonesy2.jpg')}
     />
     </View>

         <View>
    <Image
     resizeMode={'stretch'}
     style={estilo.img}
     source={require('../../assets/Jonesy3.jpg')}
     />
     </View>
     </ScrollView>
     </View>
     <View style={estilo.resumo}>
     <Text style={estilo.textoResumo}>
Quando pensamos em um verdadeiro ícone dos videogames, é impossível não lembrar do Jonesy Fortnite. Figura central no universo de Fortnite, Jonesy conquistou o coração dos jogadores desde os primeiros dias do jogo.

Mesmo entre os muitos skins famosos do Fortnite, Jonesy continua se destacando. Mas afinal, quem é Jonesy no Fortnite? Neste guia, você vai conhecer a origem, evolução e o impacto desse personagem dentro da história do jogo. Ele não é apenas um skin — é parte essencial da identidade de Fortnite.
Em sua essência, Jonesy é o personagem padrão do Fortnite. Reconhecido facilmente pelos cabelos loiros e visual atlético, ele foi um dos primeiros personagens que os jogadores encontraram no game.

Jonesy é frequentemente o protagonista nas cinemáticas oficiais, onde a história do Fortnite é apresentada. Ele também aparece em diversos eventos e colaborações, assumindo diferentes formas e skins temáticas.

Além disso, Jonesy simboliza o jogador comum. Isso faz com que muitos se identifiquem com ele, reforçando sua popularidade. Desde a primeira temporada, sua presença é constante — e até hoje, ele continua relevante.

Sua versatilidade visual permite inúmeras personalizações, o que também contribui para sua importância dentro do jogo.
</Text>
      </View>
      </View>
      </ScrollView>
  );
}
const estilo = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#800020',
  },
  img: {
    width: 330,
    height: 400,
    marginHorizontal: 25,
    borderRadius: 10,
  },
  titulo: {
    fontSize: 30,
    textAlign: 'center',
    color: '#FFC0CB',
    fontWeight: 700,
    marginTop: 50,
    marginBottom: 30,
  },
  resumo: {
    marginTop: 20,
    marginHorizontal: 15,
    backgroundColor: '#ffffff70',
    color: '#FFFFE0',
    borderRadius: 7,
    padding: 8,
  },
  textoResumo: {
    fontSize: 19,
  },
});