import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView} from 'react-native';

export default function Steve() {
  return (
    <ScrollView>
    <View style={estilo.container}>
    <Text style={estilo.titulo}> Steve</Text>
    <View>
    <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
    <View>
    <Image
     resizeMode={'stretch'}
     style={estilo.img}
     source={require('../../assets/steve1.jpg')}
     />
     </View>
     

    <View>
    <Image
     resizeMode={'stretch'}
     style={estilo.img}
     source={require('../../assets/Steve__2.png')}
     />
     </View>

         <View>
    <Image
     resizeMode={'stretch'}
     style={estilo.img}
     source={require('../../assets/steve3.jpg')}
     />
     </View>
     </ScrollView>
     </View>
     <View style={estilo.resumo}>
     <Text style={estilo.textoResumo}>
Steve é ​​um personagem jogável de Minecraft , um jogo sandbox de 2011 da Mojang Studios . Criado pelo desenvolvedor sueco de jogos Markus "Notch" Persson e introduzido na versão original para Java em 2009, Steve é ​​a primeira e a skin padrão disponível para jogadores das versões atuais de Minecraft . Steve não possui uma história oficial, pois foi concebido como um avatar personalizável , e não como um personagem predefinido. Sua contraparte feminina, Alex , foi introduzida em agosto de 2014 para as versões Java de Minecraft para PC , com outros sete personagens estreando na edição Java do jogo em outubro de 2022. Dependendo da versão de Minecraft , os jogadores podem escolher entre Steve ou qualquer outra skin variante ao criar uma nova conta. No entanto, a skin é facilmente alterada no próprio jogo ou no site.

Steve tornou-se um personagem amplamente reconhecido na indústria de videogames após o sucesso de crítica e público da franquia Minecraft . Considerado pelos críticos como um mascote da propriedade intelectual de Minecraft , sua imagem apareceu em anúncios e produtos, incluindo roupas e itens colecionáveis. Em outubro de 2020, Steve foi adicionado como personagem jogável em Super Smash Bros. Ultimate , onde é frequentemente classificado como o melhor personagem do jogo e gerou controvérsia devido ao seu poder desequilibrado, o que levou a banimentos frequentes em diversos torneios . Ele foi interpretado por Jack Black na adaptação cinematográfica de Minecraft , lançada em abril de 2025. O design de Steve também foi usado em mídias não oficiais, como a creepypasta " Herobrine " .
 </Text>
      </View>
      </View>
      </ScrollView>
  );
}
const estilo = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#800020',
  },
  img: {
    width: 330,
    height: 400,
    marginHorizontal: 25,
    borderRadius: 10,
  },
  titulo: {
    fontSize: 30,
    textAlign: 'center',
    color: '#FFC0CB',
    fontWeight: 700,
    marginTop: 50,
    marginBottom: 30,
  },
  resumo: {
    marginTop: 20,
    marginHorizontal: 15,
    backgroundColor: '#ffffff70',
    color: '#FFFFE0',
    borderRadius: 7,
    padding: 8,
  },
  textoResumo: {
    fontSize: 19,
  },
});