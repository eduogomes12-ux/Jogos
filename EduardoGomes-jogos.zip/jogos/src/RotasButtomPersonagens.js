import * as react from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import Arthur from './personagens/Arthur';
import Michael from './personagens/Michael';
import Steve from './personagens/Steve';
import Jonesy from './personagens/Jonesy';
import Personagens from './pages/Personagens';

const Stack = createStackNavigator();

export default function RotasButtomPersonagens() {
  return (
    <Stack.Navigator>
    <Stack.Screen name="Personagens" component={Personagens} options = {{headerShown:false}} />
    <Stack.Screen name="Arthur" component={Arthur} options = {{title:"Arthur Morgan"}} />
    <Stack.Screen name="Steve" component={Steve} options = {{title:"Steve"}} />
    <Stack.Screen name="Michael" component={Michael} options = {{title:"Michael"}} />
    <Stack.Screen name="Jonesy" component={Jonesy} options = {{title:"Jonesy"}} />
    </Stack.Navigator>
  );
}
