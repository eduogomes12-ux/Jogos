import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';

export default function Minecraft() {
  const jogos = 
`Minecraft é um jogo eletrônico sandbox de sobrevivência de 2011 desenvolvido e publicado pela desenvolvedora sueca Mojang Studios. Originalmente criado por Markus "Notch" Persson usando a linguagem de programação Java, a primeira versão alfa pública foi lançada em 17 de maio de 2009. O jogo foi desenvolvido continuamente a partir de então, recebendo um lançamento completo em 18 de novembro de 2011. Posteriormente, Persson deixou a Mojang e cedeu o controle do desenvolvimento a Jens "Jeb" Bergensten. Nos anos desde o seu lançamento, o jogo foi portado para diversas plataformas, incluindo smartphones, tablets e diversos consoles de jogos eletrônicos. Em 2014, a Mojang e a propriedade intelectual de Minecraft foram compradas pela Microsoft por US$ 2.5 bilhões.

Em Minecraft, os jogadores exploram um mundo aberto tridimensional intencionalmente em blocos, pixelizado e gerado proceduralmente com terreno virtualmente infinito, podendo descobrir e extrair matérias-primas, ferramentas artesanais, construir estruturas ou terraplenagens e, dependendo do modo de jogo, podem combater inimigos controlados por computador, bem como cooperar ou competir contra outros jogadores no mesmo mundo. Esses modos incluem um modo sobrevivência, no qual o jogador precisa adquirir recursos para construir o mundo e se manter vivo, e um modo criativo, onde os jogadores têm recursos ilimitados e a capacidade de voar. A grande comunidade do jogo oferece uma grande variedade de conteúdo gerado pelos usuários, como modificações, servidores, skins de jogadores, pacotes de texturas e mapas personalizados, que adicionam novas mecânicas e possibilidades ao jogo. O cenário de speedrunning do jogo atraiu um número significativo de seguidores.

Minecraft é o jogo eletrônico mais vendido de todos os tempos, vendendo mais de 425 milhões de cópias em todas as plataformas até 2026, com mais de 140 milhões de jogadores ativos mensalmente e 300 mil jogadores novos a cada dia.[19] O jogo recebeu elogios da crítica, ganhou vários prêmios e foi citado como um dos melhores jogos eletrônicos de todos os tempos; redes sociais, paródias, adaptações, produtos e as convenções anuais da Minecon desempenharam papéis importantes na popularização do jogo. Minecraft tem sido usado em ambientes educacionais para ensinar química, desenho assistido por computador e ciência da computação. A franquia Minecraft inclui vários títulos spin-off, como Minecraft: Story Mode (2015), Minecraft Earth (2019), Minecraft Dungeons (2020), Minecraft Legends (2023), Minecraft Dungeons II (2026) e o futuro Minecraft Blast. Uma adaptação cinematográfica, intitulada Um Filme Minecraft, foi lançada em 2025.

`;

  return (
    <ScrollView>
      <View style={estilo.container}>
        <Text style={estilo.titulo}>Minecraft</Text>
        <Text style={estilo.subtitulo}>
        Mojang
        </Text>

        <View style={estilo.resumo}>
          <Text style={estilo.textoResumo}>
            {jogos}
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const estilo = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#800020',
    paddingBottom: 30,
  },
  titulo: {
    fontSize: 30,
    textAlign: 'center',
    color: '#D3AF37',
    fontWeight: '700',
    marginTop: 50,
    marginBottom: 10,
  },
  subtitulo: {
    fontSize: 20,
    textAlign: 'center',
    color: '#E6E6FA',
    marginBottom: 20,
  },
  resumo: {
    marginHorizontal: 25,
    backgroundColor: '#ffffff70',
    borderRadius: 7,
    padding: 12,
  },
  textoResumo: {
    fontSize: 16,
    lineHeight: 27,
    color: '#FFFFE0',
  },
});