import React from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity,} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';

export default function Jogos(props) {
  return (
    <View style={estilo.container}>
      <Text style={estilo.titulo}> Os Melhores jogos</Text>

      <FlatList
      data={jogos}

      renderItem={({ item }) =>
      <View style={estilo.jogos}>         
      <TouchableOpacity
       onPress={() => {
       props.navigation.navigate(item.buttom);  }}>
       <Text style={estilo.txtArtista}> {item.nome}</Text>
      </TouchableOpacity>

        <View style={estilo.rede}>
          <Text style={estilo.curtidas}>
          <MaterialCommunityIcons
            name="thumb-up"
            size={20}
            color={'red'}
            />
            {item.like} Curtidas
            </Text>
            <Text style={estilo.reproducoes}>
            <MaterialCommunityIcons
            name="gamepad"       
            size={20}
            color={'blue'}
            />
            {item.reproducoes} cópias
            </Text>
          </View>
        </View>
      }
    />
    </View>
  );
}

const jogos = [
  {
    uid: 1,
    nome: 'Red Dead Redemption 2',
    like: "3M",
    reproducoes: "17,4M",
    buttom:'RedDead2',
  },
  {
    uid: 2,
    nome: 'Minecraft',
    like: "2,7M",
    reproducoes: "10,2M",
     buttom:'Minecraft',
  },
    {
    uid: 3,
    nome: 'Grand theft auto 5',
    like: "1,9M",
    reproducoes: "15,3M",
     buttom:'GrandTheftAuto',
  },
    {
    uid: 4,
    nome: 'Fortnite',
    like: "3,5M",
    reproducoes: "11,9m",
    buttom:'Fortnite',
  },
];

const estilo = StyleSheet.create({
  container:{
    flex: 1,
    backgroundColor: '#800020',
  },
 jogos: {
    backgroundColor: '#E6E6FA',
    justifyContent: 'center',
    margin: 15,
    padding: 5,
    borderRadius: 10,
    alignContent: 'center',
    textAlign: 'center',
  },
  titulo: {
    fontSize: 30,
    textAlign: 'center',
    color: '#FFD700',
    fontWeight: 700,
    marginVertical: 30,
  },
  rede: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  txtArtista: {
    fontSize: 20,
  },
});
