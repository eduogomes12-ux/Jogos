import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView} from 'react-native';

export default function Arthur() {
  return (
    <ScrollView>
    <View style={estilo.container}>
    <Text style={estilo.titulo}> Arthur</Text>
    <View>
    <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
    <View>
    <Image
     resizeMode={'stretch'}
     style={estilo.img}
     source={require('../../assets/Arthur1.webp')}
     />
     </View>
     

    <View>
    <Image
     resizeMode={'stretch'}
     style={estilo.img}
     source={require('../../assets/Arthur2.jpg')}
     />
     </View>

         <View>
    <Image
     resizeMode={'stretch'}
     style={estilo.img}
     source={require('../../assets/Arthur3.jpg')}
     />
     </View>
     </ScrollView>
     </View>
     <View style={estilo.resumo}>
     <Text style={estilo.textoResumo}>
Arthur Morgan é um personagem fictício da série de jogos eletrônicos Red Dead que serve como o protagonista principal do terceiro título da série, Red Dead Redemption 2. Um membro da gangue Van der Linde, Arthur deve lidar com o declínio do Velho Oeste enquanto tenta sobreviver contra as forças do governo. Ele é interpretado por Roger Clark.

A Rockstar Games decidiu focar Red Dead Redemption 2 em apenas um personagem, a fim de segui-lo mais pessoalmente. Eles achavam que isso era mais apropriado para a estrutura narrativa de um faroeste. Clark queria interpretar Arthur de uma maneira complexa o suficiente para que o jogador escolhesse seu caminho e ainda fizesse sentido. Ele se inspirou em atores como Toshiro Mifune, John Wayne e Rob Wiethoff, que interpretou John Marston no jogo e em seu antecessor.

Arthur foi aclamado pela crítica, sendo sua complexidade e caminho para a redenção frequentemente alvo de elogios. Os críticos também o elogiaram por trazer o mundo e outros personagens à vida. Pelo seu trabalho, Clark recebeu várias indicações e foi premiado como Melhor Performance no The Game Awards 2018.
 </Text>
      </View>
      </View>
      </ScrollView>
  );
}
const estilo = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#800020',
  },
  img: {
    width: 330,
    height: 400,
    marginHorizontal: 25,
    borderRadius: 10,
  },
  titulo: {
    fontSize: 30,
    textAlign: 'center',
    color: '#FFC0CB',
    fontWeight: 700,
    marginTop: 50,
    marginBottom: 30,
  },
  resumo: {
    marginTop: 20,
    marginHorizontal: 15,
    backgroundColor: '#ffffff70',
    color: '#FFFFE0',
    borderRadius: 7,
    padding: 8,
  },
  textoResumo: {
    fontSize: 19,
  },
});