import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';

export default function GrandTheftAuto() {
  const jogos = 
`Grand Theft Auto V é um jogo eletrônico de ação-aventura de 2013 desenvolvido pela Rockstar North e publicado pela Rockstar Games. É o sétimo título principal da série Grand Theft Auto, após Grand Theft Auto IV (2008), e o décimo quinto jogo da franquia no geral. Ambientado no estado fictício de San Andreas, baseado no sul da Califórnia, o modo história para um jogador acompanha três protagonistas — o ladrão de bancos aposentado Michael De Santa (Ned Luke), o gângster de rua Franklin Clinton (Shawn Fonteno) e o traficante de armas e drogas Trevor Philips (Steven Ogg) — e suas tentativas de realizar assaltos enquanto sofrem pressão de uma agência governamental corrupta e de criminosos poderosos. Os jogadores podem explorar livremente o mundo aberto de San Andreas e a cidade fictícia de Los Santos, baseada em Los Angeles.

O mundo do jogo é explorado a pé e de veículo, tanto em perspectiva de terceira quanto de primeira pessoa. Os jogadores controlam os protagonistas durante o modo para um jogador e podem alternar entre eles, tanto durante quanto fora das missões. A história gira em torno de sequências de assaltos, e muitas missões envolvem tiroteios e direção de veículos. Um sistema de "procurado" controla a intensidade da resposta policial aos jogadores que cometem crimes. Em Grand Theft Auto Online, o modo multijogador online do jogo, até 30 jogadores participam de diversos modos de jogo cooperativos e competitivos.

Compartilhado entre vários estúdios da Rockstar ao redor do mundo, o desenvolvimento do jogo começou por volta da época do lançamento de Grand Theft Auto IV. Os desenvolvedores se inspiraram em muitos de seus projetos anteriores (como Red Dead Redemption e Max Payne 3) e projetaram o jogo em torno de três protagonistas principais para inovar na estrutura central de seus antecessores. Grande parte do trabalho de desenvolvimento consistiu na criação do mundo aberto, e vários membros da equipe realizaram pesquisas de campo na Califórnia para capturar imagens para a equipe de design. A trilha sonora do jogo apresenta uma música original composta por uma equipe de produtores que colaboraram ao longo de vários anos. Grand Theft Auto V foi lançado em setembro de 2013 para PlayStation 3 e Xbox 360, em novembro de 2014 para PlayStation 4 e Xbox One, em abril de 2015 para Windows e em março de 2022 para PlayStation 5 e Xbox Series X/S.

Amplamente divulgado e muito aguardado, o jogo quebrou recordes de vendas na indústria e se tornou o produto de entretenimento mais vendido da história, arrecadando US$800 milhões no primeiro dia e US$1 bilhão nos primeiros três dias. Recebeu aclamação da crítica, com elogios direcionados ao seu design com múltiplos protagonistas, mundo aberto, apresentação e jogabilidade. No entanto, sua representação de violência e mulheres causou controvérsias. Diversas publicações de jogos premiaram o jogo com diversos prêmios de fim de ano, incluindo o de Jogo do Ano. Em retrospectiva, é considerado um dos títulos mais importantes da sétima e oitava geração de consoles e um dos melhores jogos já feitos. É o segundo jogo mais vendido de todos os tempos, com mais de 230 milhões de cópias distribuídas, e um dos produtos de entretenimento de maior sucesso financeiro de todos os tempos, com quase US$10 bilhões em receita mundial. Seu sucessor, Grand Theft Auto VI, tem lançamento previsto para novembro de 2026.
`;

  return (
    <ScrollView>
      <View style={estilo.container}>
        <Text style={estilo.titulo}>Grand Theft Auto 5</Text>
        <Text style={estilo.subtitulo}>
        Rockstar Games
        </Text>

        <View style={estilo.resumo}>
          <Text style={estilo.textoResumo}>
            {jogos}
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const estilo = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#800020',
    paddingBottom: 30,
  },
  titulo: {
    fontSize: 30,
    textAlign: 'center',
    color: '#D3AF37',
    fontWeight: '700',
    marginTop: 50,
    marginBottom: 10,
  },
  subtitulo: {
    fontSize: 20,
    textAlign: 'center',
    color: '#E6E6FA',
    marginBottom: 20,
  },
  resumo: {
    marginHorizontal: 25,
    backgroundColor: '#ffffff70',
    borderRadius: 7,
    padding: 12,
  },
  textoResumo: {
    fontSize: 16,
    lineHeight: 27,
    color: '#FFFFE0',
  },
});